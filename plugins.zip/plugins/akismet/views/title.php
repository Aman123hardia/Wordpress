<div class="centered akismet-box-header">
	<h2><?php esc_html_e( 'Eliminate spam from your site', 'akismet' ); ?></h2>
</div>