// Check if the form is submitted
