<?php

/** 
* Plugin Name: EventManage Plugin
* Plugin URI: https://sparxsystems.com/resources/user-guides/project-management/task-management.pdf
* Description: Using the Project Gantt View, you can review the allocation of work to elements in the project, focusing on either theelements that require work, or the resources required to perform the work. The view primarily shows informationthat isentered through other windows and dialogs, but once a record exists in the view you can edit it and, for example, addtoor change the resources on an element.
 * Version: 1.0
 * Author: Your Name
 * Author URI: http://www.mywebsite.com
 * 
 */



add_action('admin_menu', 'event_plugin_setup');
 
function event_plugin_setup(){
    //parent menu
    add_menu_page( 'Event Plugin', 
        'Event Plugin', 
        'manage_options', 
        'event_manage', 
        'event_details' );   

    // submenu
       add_submenu_page(
            'event_manage',
            'Add Event',
            'add-event',
            'manage_options',
            'add_event-manage',
            'add_event'
        );
       // submenu
       add_submenu_page(
            'event_manage',
            'Update Event',
            'update-event',
            'manage_options',
            'upd_event-manage',
            'update_event'
        );


}


//add Event start
function add_event(){

?>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

     <h1 class='text-center text-success'>Add Event Details</h1>
  <form action="" method="post">
      <div class="form-group pt-3">
        <label for="fullname">Event Name:</label>
        <input type="text" class="form-control" placeholder="Enter your Name" name="fullname">
      </div>
     <div class="form-group pt-3">
        <label for="address">Event Address:</label>
      <textarea class="form-control" name="address"  placeholder="Enter Your Address Here"></textarea>
     </div>

      <div class="form-group pt-2">
        <label for="comment">Requirement of Event</label>
        <textarea class="form-control" name="intro" placeholder="Describe Your Self" rows="3"></textarea>
      </div> 
     
     <div class="form-group pt-3">
        <label for="edate">Event Date:</label>
        <input type="text" class="form-control" placeholder="Enter your Name" name="edate">
      </div>

        <div class="form-group pt-3">
        <label for="manager">Event Manager:</label>
        <input type="text" class="form-control" placeholder="Enter Event Manager Name" name="manager">
      </div>

     <input type="submit" class="btn btn-success mt-3" name="SubmitButton" value="submit" />
  </form>

  <?php 
      do_action('form_submit','profile_details');   
}



function event_details(){
     $index=1;
     global $wpdb;
     $table= $wpdb->prefix.'eventManage';
     $rows= $wpdb->get_results("SELECT * from $table");
     echo "  
       <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css' rel='stylesheet'>  
       <h1 class='text-center text-primary'>All Event List </h1><hr>
      <table class='table'>
            <thead class='text-center'>
                <tr>
                    <th>S.No</th>
                    <th>Event Name</th>
                    <th>Event Address</th>
                    <th>Event Requirement</th>
                    <th>Event Date</th>
                    <th>Event Manager</th>
                    <th>Manage Event</th>
            
                </tr>
              </thead>
              <tbody class='text-center'> ";
           $profileData='';

          foreach ($rows as $row) { 

            echo '<tr><td> '.$index++.'</td> <td>'.$row->event_name.' </td> <td>  '. $row->event_address.' </td> <td>  '.$row->event_requirement.' </td> <td> '.$row->event_date.'</td><td>  '. $row->event_manager;
echo '<td style="padding-left:100px"><a href="http://localhost/wordpress/wp-admin/admin.php?page=upd_event-manage&id=' . $row->event_id . '">edit</a></td>';

    
       }
   }






function update_event(){
         global $wpdb;
    $table= $wpdb->prefix.'eventManage';
      if (isset($_GET['id'])) 
    $id = $_GET['id'];
  $query = "SELECT * FROM $table WHERE `event_id` = '$id'";
    $rows = $wpdb->get_results($query);
foreach ($rows as $row) {
    print_r($row->event_name);

}


if(!empty($rows)){
?>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

     <h1 class='text-center text-success'>Update Event Details</h1>
    <form action="" method="post">
       <?php foreach ($rows as $row) {?>
      <div class="form-group pt-3">
        <label for="fullname">Event Name:</label>
        <input type="text" class="form-control" placeholder="Enter your Name" name="fullname" value='<?php echo $row->event_name; ?>'>
      </div>
        <div class="form-group pt-3">
        <label for="address">Event Address:</label>
      <textarea class="form-control" name="address"  placeholder="Enter Your Address Here"><?php echo $row->event_address; ?></textarea>
     </div>

      <div class="form-group pt-2">
        <label for="comment">Requirement of Event</label>
        <textarea class="form-control" name="intro" placeholder="Describe Your Self" rows="3"><?php echo $row->event_requirement; ?></textarea>
      </div> 
     
     <div class="form-group pt-3">
        <label for="edate">Event Date:</label>
        <input type="text" class="form-control" placeholder="Enter your Name" name="edate" value='<?php echo $row->event_date; ?>'>
      </div>

        <div class="form-group pt-3">
        <label for="manager">Event Manager:</label>
        <input type="text" class="form-control" placeholder="Enter Event Manager Name" name="manager" value='<?php echo $row->event_manager; ?>'>
      </div>
       <?php
  }?>
     <input type="submit" class="btn btn-success mt-3" name="SubmitButton" value="submit" />
     <?php 
 echo '<a href="http://localhost/wordpress/wp-admin/admin.php?page=upd_event-manage&id=' . $row->event_id . '"><button type="submit" class="btn btn-success mt-3" name="SubmitButton" value="Delete">Delete</button> </a>';
   ?>

     <input type="submit" class="btn btn-success mt-3" name="SubmitButton" value="Back"/>
  </form>

  <?php 
      // do_action('form_submit','profile_details');   
}
     }

?>
