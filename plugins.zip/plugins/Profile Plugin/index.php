<?php

/** 
* Plugin Name: Profile Plugin
* Plugin URI: https://sparxsystems.com/resources/user-guides/project-management/task-management.pdf
* Description: Using the Project Gantt View, you can review the allocation of work to elements in the project, focusing on either theelements that require work, or the resources required to perform the work. The view primarily shows informationthat isentered through other windows and dialogs, but once a record exists in the view you can edit it and, for example, addtoor change the resources on an element.
 * Version: 1.0
 * Author: Your Name
 * Author URI: http://www.mywebsite.com
 * 
 */



add_action('admin_menu', 'profile_plugin_setup');
 
function profile_plugin_setup(){
    //parent menu
    add_menu_page( 'Profile Plugin', 
        'Profile Plugin', 
        'manage_options', 
        'profile_detail', 
        'profile_details' );   

    // submenu
       add_submenu_page(
            'profile_detail',
            'detail_list',
            'detail_list',
            'manage_options',
            'detail_data',
            'details'
        );

       //
       // submenu
       add_submenu_page(
            'profile_detail',
            'edit_list',
            'edit_list',
            'manage_options',
            'edit_data',
            'editDetails'
        );

}


//parent Menu
function profile_details(){

?>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

     <h1 class='text-center text-success'>Profile Details</h1>
  <form action="" method="post">
      <div class="form-group pt-3">
        <label for="fullname">Name:</label>
        <input type="text" class="form-control" placeholder="Enter your Name" name="fullname">
      </div>
        <div class="form-group pt-3">
        <label for="email">Email :</label>
        <input type="email" class="form-control" placeholder="Enter your Email" name="email">
      </div>
     <div class="form-group pt-3">
        <label for="address">Address:</label>
      <textarea class="form-control" name="address"  placeholder="Enter Your Address Here"></textarea>
     </div>

      <div class="form-group pt-2">
        <label for="comment">Describe Your Self</label>
        <textarea class="form-control" name="intro" placeholder="Describe Your Self" rows="3"></textarea>
      </div> 

     <input type="submit" class="btn btn-success mt-3" name="SubmitButton" value="submit" />
  </form>

  <?php 
      do_action('form_submit','profile_details');   
}


//list

function details(){
       do_action('profile_detailsList','details'); 
}


function profile_data(){
     global $wpdb;
     $table= $wpdb->prefix.'profile_details';
     $rows= $wpdb->get_results("SELECT * from $table");
     $profileData='';

          foreach ($rows as $row) { 

            $profileData .= '<tr><td> '.$row->Name.' </td> <td>  '. $row->Email.' </td> <td>  '.$row->Address.' </td> <td> '.$row->About_Us.'</td> </tr> <br>';
          
                    } 

             return $profileData;
       }


 add_shortcode('profile_form', 'profile_data');
?>