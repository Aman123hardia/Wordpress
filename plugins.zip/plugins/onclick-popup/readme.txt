=== Onclick Popup ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/
Author URI: http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/
Plugin URI: http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/
Tags: Popup, onclick, plugin, widget
Requires at least: 3.5
Tested up to: 6.1
Stable tag: 7.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

WordPress onclick Popup plugin will create a popup message to your website. The popup will appear on text click so it is named on-click popup.

== Description ==

One easy way to send your visitors a welcome message, notice, or advertisement is to add this popup plugin to your site.

Check official website for live demo [http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/](http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/)

*   [Live Demo](http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/)	
*   [More info](http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/)				
*   [Comments/Suggestion](http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/)		
*   [About author](http://www.gopiplus.com/work/)			

One easy way to send your visitors a welcome message, notice, or advertisement is to add this popup plugin to your site. WordPress on-click Popup plugin will create a popup message to your website. The popup will appear on text click so it is named on-click popup. Sometimes it's useful to add a popup to your website to show your ads, special announcement and for offers. Using this plug-in you can create unblock-able, dynamic and fully configurable popups to your blog.

Available Fancy Effect

*   Simple.
*   Easy installation.
*   Easy configuration.
*   Unblockable.
*   Popup appear on text click.

We can configure this plug-in in three different way.

Short code available,	

http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/

== Installation ==

[Installation Instruction](http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/)								
[Configuration](http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/)											

== Frequently Asked Questions ==

Q1. How to arrange the popup window width?

Q2. Is possible to add the pop up into the particular page/post?

Q3. How to update the popup information/content?

Q4. How to arrange the popup window position?

[Frequently Asked Questions](http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/)			

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/

2. Admin Screen. http://www.gopiplus.com/work/2011/11/13/wordpress-plugin-onclick-popup/

== Changelog ==

= 1.0 =			

First version.			

= 2.0 =

Tested up to 3.4

= 3.0 =

New demo link, http://www.gopiplus.com

= 4.0 =

Tested up to 3.4.2
Slight change in the short code, Please find the new short code for your popup.

= 4.1 =

Tested up to 3.5

= 5.0 =

Tested up to 3.6
Added few security features.
New admin layout.

= 5.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (onclickpopup.po) available in the languages folder.

= 5.2 =

1. Tested up to 3.9

= 5.3 =

1. Options to add Expiration date for popup message.
2. Support short code in the popup (i.e You can add other plugin short code inside this popup window)

= 5.4 =

1. Tested up to 4.0

= 5.5 =

1. Tested up to 4.1

= 5.6 =

1. Tested up to 4.2.2

= 5.7 =

1. Tested up to 4.3

= 5.8 =

1. Tested up to 4.4
2. Text Domain slug has been added for Language Packs.

= 5.9 =

1. Tested up to 4.5
2. Sanitization added for all input value.

= 6.0 =

1. Tested up to 4.6

= 6.1 =

1. Tested up to 4.7

= 6.2 =

1. Tested up to 4.8

= 6.3 =

1. Tested up to 4.9

= 6.4 =

1. Tested up to 5.1
2. Converted JS alert message into WP class file.

= 6.5 =

1. Tested up to 5.2
2. Uninstall option added. All plugin reference and plugin table will be cleared during uninstallation.

= 6.6 =

1. Tested up to 5.3

= 6.7 =

1. Tested up to 5.4

= 6.8 =

1. Tested up to 5.5

= 6.9 =

1. Tested up to 5.7

= 7.0 =

1. Tested up to 5.8
2. Use plugin short code in the widget.

= 7.1 =

1. Tested up to 5.9

== Upgrade Notice ==

= 1.0 =			

First version.			

= 2.0 =

Tested up to 3.4

= 3.0 =

New demo link, http://www.gopiplus.com

= 4.0 =

Tested up to 3.4.2
Slight change in the short code, Please find the new short code for your popup.

= 4.1 =

Tested up to 3.5

= 5.0 =

Tested up to 3.6
Added few security features.
New admin layout.

= 5.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (onclickpopup.po) available in the languages folder.

= 5.2 =

1. Tested up to 3.9

= 5.3 =

1. Options to add Expiration date for popup message.
2. Support short code in the popup (i.e You can add other plugin short code inside this popup window)

= 5.4 =

1. Tested up to 4.0

= 5.5 =

1. Tested up to 4.1

= 5.6 =

1. Tested up to 4.2.2

= 5.7 =

1. Tested up to 4.3

= 5.8 =

1. Tested up to 4.4
2. Text Domain slug has been added for Language Packs.

= 5.9 =

1. Tested up to 4.5
2. Sanitization added for all input value.

= 6.0 =

1. Tested up to 4.6

= 6.1 =

1. Tested up to 4.7

= 6.2 =

1. Tested up to 4.8

= 6.3 =

1. Tested up to 4.9

= 6.4 =

1. Tested up to 5.1
2. Converted JS alert message into WP class file.

= 6.5 =

1. Tested up to 5.2
2. Uninstall option added. All plugin reference and plugin table will be cleared during uninstallation.

= 6.6 =

1. Tested up to 5.3

= 6.7 =

1. Tested up to 5.4

= 6.8 =

1. Tested up to 5.5

= 6.9 =

1. Tested up to 5.7

= 7.0 =

1. Tested up to 5.8
2. Use plugin short code in the widget.

= 7.1 =

1. Tested up to 5.9