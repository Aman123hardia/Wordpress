<?php
// Template Name: Ajax Page


?>

<div class="search_box" >
    <form  action='' method="get" autocomplete="off">
        <input type="text" name="s" placeholder="Search Code..." id="keyword" class="input_search" onfocusout ="fetch()">
        <button>
            Search
        </button>
    </form>

</div>