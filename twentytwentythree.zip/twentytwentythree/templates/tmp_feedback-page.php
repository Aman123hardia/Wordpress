<?php
/* Template Name: Feedback Page */


if(isset($_POST) && $_POST['SubmitButton']=="submit"){
    global $wpdb;
    $table_name = $wpdb->prefix.'feedback';
    $data = array('comment' => $_POST["comment"], 'feedback' => $_POST["feedback"], 'name' => $_POST["fullname"]);
    $format = array( '%s', '%s', '%s');
    $wpdb->insert($table_name,$data,$format);
     // print_r($table_name); 
     // print_r($data); 
     // print_r($format);die(); 
  $message = "feedback form successfully submited";
}
 echo   '<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">';
?>



  <link href="style.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container bg-light">
  <h2 class='container-fluid text-primary text-center'>Feedback Form</h2>
    <form action="" method="post">
      <div class="form-group pt-3">
        <label for="fullname">Name:</label>
        <input type="text" class="form-control" placeholder="Enter your Name" name="fullname">
      </div>
        <div class="form-group pt-3">
      <select name="feedback" class="form-control">  
        <option value = "Normal" selected> Normal </option>  
        <option value = "Good" > Good </option>  
        <option value = "Bad" >Bad</option>  
      </select>  
        <div class="form-group pt-3">
      <div class="form-group pt-2">
        <label for="comment">Comment</label>
        <textarea class="form-control" name="comment" rows="3"></textarea>
      </div>
     <input type="submit" class="btn btn-success mt-3" name="SubmitButton" value="submit" />
  </form>
</div>

<?php get_footer();?>