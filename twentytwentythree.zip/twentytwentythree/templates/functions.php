<!-- add_filter( 'the_title', 'filter_the_content_in_the_main_loop', 1 );

function filter_the_content_in_the_main_loop( $title ) {

    return $title.'.';
}
 -->

 <?php
 function my_ajax_data() {
    echo 'function Called';
    die();

    // Example response
    $response = array(
        'message' => 'AJAX request successful!',
    );

    wp_send_json($response);
}
add_action('wp_ajax_my_ajax_action', 'my_ajax_data'); 
 ?>