<?php
/* Template Name: Ajax Page */


function enqueue_ajax_scripts() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('wp-ajax-response', admin_url('admin-ajax.php'));
}
add_action('wp_enqueue_scripts', 'enqueue_ajax_scripts');

get_header();

?>
  <link href="style.css" rel="stylesheet"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

<div class="container bg-light">
  <h2 class='container-fluid text-primary text-center'>Ajax Form</h2>
<form  action="" id="myForm">
   <input type="text" name="fname">
   <input type="text" name="lname">
   <input type="text" name="email">
    <input type="submit" onclick="ajax_function()">
</form>

<button type="button" id="some_id">Send Request</button>
</div>
<script type="text/javascript">
	$.post('mail.php', $('#myForm').serialize());
	// JQuery('#myForm').submit(function(){
	// 	<?php echo 'Ajax Called'; ?>
    //   event.preventDefault();
    //   alert('s');
	// });
      
      function ajax_function(e){
      	e.preventDefault();
      	alert('AjaxCall');
      }


	// jQuery('#myForm').ready(function(e) {
	// 	e.preventDefault();
	// 	alert('s');


	//  $("form").submit(function(e) {
    // e.preventDefault();
    // $.ajax({
    //   type: 'POST',
    //   url: 'save.asmx/saveData',
    //   dataType: 'json',
    //   contentType:"application/json;charset=utf-8",
    //   data: $('form').serialize(),
    //   async:false,
    //   success: function() {
    //     alert("success");
    //   }
    //   error: function(request,error) {
    //     console.log("error");
    //   }

     
});





</script>

<?php get_footer();?>