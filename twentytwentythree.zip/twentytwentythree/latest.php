<?php
/*
Plugin Name: Latest Posts Plugin
Plugin URI: https://www.example.com/latest-posts-plugin
Description: Display the latest blog posts on a designated page or widget area.
Version: 1.0
Author: Your Name
Author URI: https://www.example.com/
*/

// Enqueue necessary scripts and styles
function latest_posts_enqueue_scripts() {
    wp_enqueue_style('latest-posts-style', plugin_dir_url(__FILE__) . 'css/latest-posts-style.css');
}
add_action('wp_enqueue_scripts', 'latest_posts_enqueue_scripts');

// Create an options page in the admin dashboard
function latest_posts_plugin_menu() {
    add_options_page('Latest Posts Plugin Settings', 'Latest Posts Plugin', 'manage_options', 'latest-posts-plugin', 'latest_posts_plugin_options');
}
add_action('admin_menu', 'latest_posts_plugin_menu');

// Render the options page
function latest_posts_plugin_options() {
    if (!current_user_can('manage_options')) {
        wp_die('You do not have sufficient permissions to access this page.');
    }

    // Save the options on form submission
    if (isset($_POST['latest_posts_submit'])) {
        update_option('latest_posts_count', $_POST['latest_posts_count']);
        update_option('latest_posts_orderby', $_POST['latest_posts_orderby']);
    }

    // Retrieve saved options
    $latest_posts_count = get_option('latest_posts_count', 5);
    $latest_posts_orderby = get_option('latest_posts_orderby', 'date');

    // Display the options form
    ?>
    <div class="wrap">
        <h1>Latest Posts Plugin Settings</h1>
        <form method="post" action="">
            <label for="latest_posts_count">Number of Posts to Display:</label>
            <input type="number" name="latest_posts_count" id="latest_posts_count" value="<?php echo esc_attr($latest_posts_count); ?>" min="1" max="10" required>

            <label for="latest_posts_orderby">Post Order:</label>
            <select name="latest_posts_orderby" id="latest_posts_orderby">
                <option value="date" <?php selected($latest_posts_orderby, 'date'); ?>>Date</option>
                <option value="title" <?php selected($latest_posts_orderby, 'title'); ?>>Title</option>
            </select>

            <input type="submit" name="latest_posts_submit" class="button-primary" value="Save Changes">
        </form>
    </div>
    <?php
}

// Create shortcode for displaying latest posts
function latest_posts_shortcode($atts) {
    // Retrieve shortcode attributes
    $atts = shortcode_atts(array(
        'count' => get_option('latest_posts_count', 5),
        'orderby' => get_option('latest_posts_orderby', 'date')
    ), $atts);

    // Query latest posts
    $latest_posts_args = array(
        'post_type' => 'post',
        'posts_per_page' => intval($atts['count']),
        'orderby' => $atts['orderby']
    );
    $latest_posts_query = new WP_Query($latest_posts_args);

    // Start output buffer
    ob_start();

    // Display latest posts
    if ($latest_posts_query->have_posts()) {
        while ($latest_posts_query->have_posts()) {
            $latest_posts_query->
